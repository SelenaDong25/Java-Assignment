/*
Program:  TicTacToe Game.
This is a program that allows two players to play a game of tic-tac-toe 
on 4x4 board. 
Program written by: Xin Dong
Date: Feb. 25, 2019
 */
package tictactoe;

// import for user input
import java.util.Scanner;

public class TicTacToe {

    private char[][] board;
    private boolean status;
    private char winner; //X, O, T for tie, P for playing
    private boolean whoseTurn; // True for X, False for O
    
    // No-argument constructor and initialize the board setting
    public TicTacToe() {
        //create new board and initial board charactor
        char[][] newBoard = 
        {{'1', '2', '3', '4'},
        {'5', '6', '7', '8'},
        {'9', 'a', 'b', 'c'},
        {'d', 'e', 'f', 'g'}};
        // assign board charactor to board array
        board = newBoard;
        // initial status set to false
        status = false;
        // initial winner set to playing
        winner = 'P';
        // initial player set to X
        whoseTurn = true;

    }
    /**
     The method is to print board for player to play.  
    */
    public void printBoard() {

        // i == rows
        for(int i = 0; i < 4; i ++)
        {
            // j == columns
            for(int j = 0; j < 4; j++)
            {
                // print columns
                System.out.print(board[i][j]+" ");
            }
            // print rows
            System.out.println();
        }
    }
    /**
     The method is to prompt user to pick a spot and input.
    */
    public void input() {
        // create new empty board
        char[][] emptyBoard = 
        {{'1', '2', '3', '4'},
        {'5', '6', '7', '8'},
        {'9', 'a', 'b', 'c'},
        {'d', 'e', 'f', 'g'}};
        
        // create new scanner object
        Scanner keyboard = new Scanner(System.in);
        
        // create bolean variable and initialize it
        boolean validMove = false;
        // loop to keep playing when moves are valid
        while(validMove == false)
        {
            // when whoseTurn is true, print message to let Player X to play
            // when whoseTurn is false, print message to let Player O to play
            if(whoseTurn)
            {
                System.out.print("Player X, it is your turn to pick a spot: ");
            }
            else
            {
                System.out.print("Player O, it is your turn to pick a spot: ");
            }
            // user input string first charactor is stored in nextInput variable
            char nextInput = keyboard.nextLine().charAt(0);
            
            
            //check if move is in empty board
            boolean validChar = false;
            
            for(int i = 0; i < 4; i ++)
            {
                for(int j = 0; j < 4; j++)
                {
                    if(emptyBoard[i][j] == nextInput)
                    {
                        validChar = true;
                    }                  
                }
            }
            //VALIDATE IF INPUT IS VALID CHARACTER
            if(validChar == false)
            {
                System.out.println("Please enter a valid character!");
                
            }
            else
            {
                //check if move is in current board
                for(int i = 0; i < 4; i ++)
                {
                    for(int j = 0; j < 4; j++)
                    {
                        if(board[i][j] == nextInput)
                        {
                            if(whoseTurn == true)
                            {
                                board[i][j] = 'X';
                            }
                            else
                            {
                                board[i][j] = 'O';
                            }

                            validMove = true;
                            break;
                        }                  
                    }
                }   
                //validate if move spot is available
                if(validMove == false)
                {
                    System.out.println("Please enter a move that hasn't already been played!");
                }                           
            }
  
        }
        // reverse player to play
        if(whoseTurn == true)
        {
            whoseTurn = false;
        }
        else
        {
            whoseTurn = true;
        }      
    }
    /**
     The method is to return game status.
     @return status to indicate the game is end or keep playing.  
    */
    public boolean done() {      
        return status;
    }
    /**
     The method is to create Constructor with parameter and been used for debugging purposes.
     @param player  defines which player's turn to play.
     @param letter  defines which spot is picked to play.
     @throws IllegalArgumentException when the value of parameter invalid.  
    */    
    public void simulateInput(char player, char letter)throws IllegalArgumentException
    {
        
        if(whoseTurn == true)
        {
            if(player != 'X') 
            {
                throw new IllegalArgumentException("ERROR:Player O, out of turn!");
            }
        }
        else
        {
            if(player != 'O')
            {
                throw new IllegalArgumentException("ERROR:Player X, out of turn!");
            }
        }
        
        char[][] emptyBoard = 
        {{'1', '2', '3', '4'},
        {'5', '6', '7', '8'},
        {'9', 'a', 'b', 'c'},
        {'d', 'e', 'f', 'g'}};
        

        
        
        //check if move is in empty board
        boolean validChar = false;
            
        for(int i = 0; i < 4; i ++)
        {
            for(int j = 0; j < 4; j++)
            {
                if(emptyBoard[i][j] == letter)
                {
                    validChar = true;
                }                  
            }
        }
        if(validChar == false)
        {
            throw new IllegalArgumentException("ERROR: Please enter a valid character!"); 
        }
        //declare valid move boolean variable
        boolean validMove = true;
        //check if move is current board
        for(int i = 0; i < 4; i ++)
        {
            for(int j = 0; j < 4; j++)
            {
                if(board[i][j] == letter)
                {
                    if(whoseTurn == true)
                    {
                        board[i][j] = 'X';
                    }
                    else
                    {
                        board[i][j] = 'O';
                    }

                    validMove = true;
                    break;
                }                  
            }
        }   
                
        if(validMove == false)
        {
            throw new IllegalArgumentException("ERROR: Move is already taken!"); 
        }   
        
        // Call printBoard to print board
        printBoard();
        
        
        // validate if winner is out of move
        if(whoseTurn == true)
        {
            System.out.println("Player X moved to "+letter+"!");
            whoseTurn = false;
        }
        else
        {
            System.out.println("Player O moved to "+letter+"!");
            whoseTurn = true;
        } 
        
    }
    /**
     The method is to return the winner
     @return winner.  
    */       
    public char whoWon(){
        return winner;  
    }
    
     /**
     The method is to analysis played board to see which winner reach 3 same 
     characters in a line and indicate who is the winner
    */      
    public void analyzeBoard()
    {
        char player = 'X';
        
        if(whoseTurn == true)
        {
            player = 'O';
        }
        boolean foundWinner = false;
        boolean win = true;
        
        
        //Horizontal For-loops to find who is the winner
        for(int x=0; x<4; x++)
        {     
            win = true;
            for(int y=0; y<3; y++){
                if(board[x][y] != player){
                    win = false;
                }           
            }
            if(win == true){
                foundWinner = true;
            }
                   
            win = true;
            for(int y=1; y<4; y++){
                if(board[x][y] != player){
                    win = false;
                }           
            }
            if(win == true){
                foundWinner = true;
            }         
        }
        

        
        //Vertical For-loops to find who is the winner
        for(int y=0; y<4; y++)
        {     
            win = true;
            for(int x=0; x<3; x++){
                if(board[x][y] != player){
                    win = false;
                }           
            }
            if(win == true){
                foundWinner = true;
            }
                   
            win = true;
            for(int x=1; x<4; x++){
                if(board[x][y] != player){
                    win = false;
                }           
            }
            if(win == true){
                foundWinner = true;
            }         
        }
        
        
        //Diagonal Checks to find who is the winner      
        if(board[1][0] == player && board[2][1] == player && board[3][2] == player)
        {
            foundWinner = true;
        }
        else if(board[1][1] == player && board[2][2] == player && board[3][3] == player)
        {
            foundWinner = true;
        }
        else if(board[0][0] == player && board[1][1] == player && board[2][2] == player)
        {
            foundWinner = true;
        }
        else if(board[0][1] == player && board[1][2] == player && board[2][3] == player)
        {
            foundWinner = true;
        }
        else if(board[1][3] == player && board[2][2] == player && board[3][1] == player)
        {
            foundWinner = true;
        }
        else if(board[0][3] == player && board[1][2] == player && board[2][1] == player)
        {
            foundWinner = true;
        }
        else if(board[1][2] == player && board[2][1] == player && board[3][0] == player)
        {
            foundWinner = true;
        }
        else if(board[0][2] == player && board[1][1] == player && board[2][0] == player)
        {
            foundWinner = true;
        }

        
        
        
        //Winner was found, give the winner is X or O
        if(foundWinner == true)
        {
            
            winner = player;
            status = true;          
        }
        
        
    }
    
    


}
