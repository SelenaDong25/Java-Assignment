
/*
   Program: Geometry.java
   Created by Xin Dong
   This program is to calculate geometry areas
   January 13, 2019
 */

import java.util.Scanner; // Needed for the Scanner class
import java.text.DecimalFormat;  // Needed for double number roundup

public class Geometry 
{
    public static void main(String[] args) 
    {
        // Display menu
        System.out.println  
        (
            "Geometry Calculator: \n" + 
            "\t1. Calculate the Area of a Circle\n"+
            "\t2. Calculate the Area of a Rectangle\n"+
            "\t3. Calculate the Area of a Triangle\n"+
            "\t4. Quit\n"+
            "Enter your choice (1 – 4): "
        );

        // Declare variables for holding input numbers
        double radius, length, width, base, height, area;
        int inputNumber;
        // Declare contant value for PI
        final double PI = 3.14159;
        // Formatting double numbers to 2 decimals
        DecimalFormat df = new DecimalFormat ("###.##"); 

        // create scanner object to read input
        Scanner keyboard = new Scanner(System.in);
        // Prompt user to enter the choice.
        System.out.print("Please enter your choice:");
        // Input choice 
        inputNumber = keyboard.nextInt();
        // Validate if the choice is within 1~4, if true, keep running the program
        if (inputNumber <=0 || inputNumber > 4)
           System.out.println("The number you selected is invalid!");
        else
        // Switch function to run program, then print out the results
        // While loop to validate input number is greater than 0
           switch (inputNumber)
           {
               case 1:
                   System.out.print("Enter the circle radius:");
                   radius = keyboard.nextDouble();
                   while (radius < 0)
                   {
                        System.out.println("Input is invalid!");
                        System.out.println("Input positive numbers:");
                        radius = keyboard.nextInt();
                   }
                   area = PI* (Math.pow(radius,2)); 
                   System.out.println("Area of Circle is: " + df.format(area) );
                   break;
               case 2:
                   System.out.print("Enter the rectangle length:");
                   length = keyboard.nextDouble();
                   while (length < 0)
                   {
                        System.out.println("Input is invalid!");
                        System.out.println("Input positive numbers:");
                        length = keyboard.nextDouble(); 
                   }
                   System.out.print("Enter the rectangle width:");
                   width = keyboard.nextDouble();
                   while (width < 0)
                   {
                        System.out.println("Input is invalid!");
                        System.out.println("Input positive numbers:");
                        width = keyboard.nextDouble();
                   }
                   area = length * width;
                   System.out.println("Area of Rectangle is: " + df.format(area) );
                   break;
               case 3:
                   System.out.print("Enter the triangle base:");
                   base = keyboard.nextDouble();
                   while (base < 0)
                   {
                        System.out.println("Input is invalid!");
                        System.out.println("Input positive numbers:");
                        base = keyboard.nextDouble();
                   }
                   System.out.print("Enter the triangle height:");
                   height = keyboard.nextDouble();
                   while (height < 0)
                   {
                        System.out.println("Input is invalid!");
                        System.out.println("Input positive numbers:");
                        height = keyboard.nextDouble();
                   }
                   area = base * height * 0.5;
                   System.out.println("Area of Triangle is: " + df.format(area));
                   break;
               default:
                   System.out.println("You ended the program.");
                   System.exit(0);
                   
           }                                     
   
        // ********* Program solution algorithm ***********
    
        // Implement the following step-by-step plan
    
        // 1. Import Scanner and DecialFormat class
        // 2. Display the selection menu
        // 3. Declare double and interger variable to store input data  
        // 4. Set Constant value
        // 5. Set decial place format for double number
        // 6. Prompt the user to input valid choice 
        // 7. Prompt user to input valid radius, length, width, base and height
        // 8. Calculate geometry areas 
        // 9. Print out calculation results.
    
        // ********* Program solution algorithm ***********   */
    }
}
