/*
   Program: MathTutor.java
   Created by Xin Dong
   This program is to be used as math tutor for young students
   January 13, 2019
 */

import java.util.Random;
import java.util.Scanner; // Needed for the Scanner class

public class MathTutor 
{
    public static void main(String[] args) 
    {
        // Display menu
        System.out.println  
        (
            "Math Tutor \n" + 
            "\t1. Addition problem\n"+
            "\t2. Subtraction problem\n"+
            "\t3. Quit\n"+
            "Enter your choice (1 - 3): "
        );
        // Declare variables for holding input choice
        int inputChoice;
        // create scanner object to read input
        Scanner keyboard = new Scanner(System.in);
        // Input choice 
        inputChoice = keyboard.nextInt();
        // Declare variables to hold random numbers, calculations
        int number1, number2, aboveNumber, belowNumber, randomNumber;
        int inputResult, calculation;
        Random randomNumbers = new Random();//Create a Random class object

        // Validate if the choice is within 1~3, 
        while (inputChoice <=0 || inputChoice > 3)
        {
            System.out.println("The number you selected is invalid!");
            System.out.println  
                (
                "Math Tutor \n" + 
                "\t1. Addition problem\n"+
                "\t2. Subtraction problem\n"+
                "\t3. Quit\n"+
                "Enter your choice (1 - 3): "
                );
            inputChoice = keyboard.nextInt();
        }
        //Loop program when student choose 1 or 2
        while (inputChoice ==1 || inputChoice ==2) 
        {
            switch(inputChoice)
            {
                case 1: // Calculate Addition 
                //{
                    number1 = randomNumbers.nextInt(999);//Generate random number1
                    number2 = randomNumbers.nextInt(999);//Generate random number2
                    System.out.println("Calculate the formula and input your answer: "); //Prompt to student to input answer
                    aboveNumber = number1 > number2 ? number1: number2; //Define the greater number
                    belowNumber = number1 < number2 ? number1: number2; //Define the smaller number
                    System.out.printf("%4d\n", aboveNumber); // Set numbers to be aligned from right
                    System.out.printf("+%3d\n", + belowNumber);
                    System.out.println("----");
                    calculation = aboveNumber + belowNumber; // Calculate the correct answer
                    inputResult = keyboard.nextInt();// Hold student input answer
                    // Compare if the student input answer is correct
                    if (inputResult == calculation)
                        System.out.println("Congratulations!Your answer is correct!");
                    else
                        System.out.println("The correct answer is " + calculation); 
                //}
                    break;                           
                case 2: // Calculate Substraction   
                //{            
                    number1 = randomNumbers.nextInt(999);//Generate random number1
                    number2 = randomNumbers.nextInt(999);//Generate random number2
                    System.out.println("Calculate the formula and input your answer: "); //Prompt to student to input answer
                    aboveNumber = number1 > number2 ? number1: number2; //Define the greater number
                    belowNumber = number1 < number2 ? number1: number2; //Define the smaller number
                    System.out.printf("%4d\n", aboveNumber); // Set numbers to be aligned from right
                    System.out.printf("-%3d\n", + belowNumber);
                    System.out.println("----");
                    calculation = aboveNumber - belowNumber; // Calculate the correct answer
                    inputResult = keyboard.nextInt();// Hold student input answer
                    // Compare if the student input answer is correct
                    if (inputResult == calculation)
                        System.out.println("Congratulations!Your answer is correct!");
                    else
                        System.out.println("The correct answer is " + calculation);
                    break;                                   
            }
     
            // Loop to print menu after addition or substtraction calculation
            System.out.println   
                    (
                    "Math Tutor \n" + 
                    "\t1. Addition problem\n"+
                    "\t2. Subtraction problem\n"+
                    "\t3. Quit\n"+
                    "Enter your choice (1 - 3): "
                    );
            inputChoice = keyboard.nextInt();
            //Loop input invalidation
            while (inputChoice <=0 || inputChoice > 3)
            {
                System.out.println("The number you selected is invalid!");
                System.out.println  
                    (
                    "Math Tutor \n" + 
                    "\t1. Addition problem\n"+
                    "\t2. Subtraction problem\n"+
                    "\t3. Quit\n"+
                    "Enter your choice (1 - 3): "
                    );
                inputChoice = keyboard.nextInt();
            }                           
        }
        // When student choose 3, program end
        while (inputChoice == 3)
        {         
            System.out.println("You ended the program.");
            System.exit(0);
        }
       
    }                             
}

        // ********* Program solution algorithm ***********   
    
        // 1. Print menu to let student select option
        // 2. Use while loop to validate input
        // 3. Enable Random object to generate random numbers 
        // 4. Switch statement for programs selection
        // 5. Add While loop to print menu again after addition or substtraction calculation
        // 6. Nested while loop to validate input 
        // 7. Use if else statement to validate if student's answer is correct
        // 8. Use printf and println to print formula on screen in the certain way 
        // 9. 
    
        // ********* Program solution algorithm ***********   */