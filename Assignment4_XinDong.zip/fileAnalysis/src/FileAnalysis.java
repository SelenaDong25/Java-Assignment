
/*
   Program: FileAnalysis.java
   Created by: Xin Dong

   This program is to analyze the sequence of integers stored in a file with a given 
   name (inputFileName), and calculates the following statistics about the data:
    • the number of integers stored,
    • the largest and the smallest number stored in file,
    • the total of all numbers stored in the file.
   All these statistics will be stored in another file.

   January 29, 2019
 */
import java.io.*; // Needed for File I/O classes
import java.util.Scanner; // Needed for Scanner class


public class FileAnalysis {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)  {
 
        // Call fileAnalysis method to run the process.
        // Print out the total processed numbers in file
        // Use try/catch clause to catch exceptions        
        try{
            int count = fileAnalysis("testFile.txt","testOutput.txt");
            
            System.out.println("Number of numbers in the file: "+count);
        }
        catch(Exception e)
        {
            System.out.println("Error: "+e.getMessage());
        }
    }
/** The method is to analyze the sequence of integers stored in a file with a given 
    name (inputFileName), and calculates the following statistics about the data:
    • the number of integers stored,
    • the largest and the smallest number stored in file,
    • the total of all numbers stored in the file.
    All these statistics will be stored in another file with a given name (outputFileName).    
     @param inputFileName  defines the input file name
     @param outputFileName defines the output file name
     @throws IOException when the files fail to open for reading and writing..  
 */
    public static int fileAnalysis (String inputFileName, String outputFileName) throws IOException
    {                         
        // Open the file. At this point an exception may be thrown        
        File file = new File(inputFileName);
        
        // If file doesn't exist, return value 0
        if(!file.exists())
        {
            return 0;
        }
        // Create Scanner object
        Scanner inputFile = new Scanner(file);        
        // This loop processes the lines read from the file,
        // until the end of the file is encountered.
        // Declare and initial variables
        int total = 0, count =0, max =0, min =0;
        // initial the first number as max or min
        if(inputFile.hasNext())
        {
            int first = inputFile.nextInt();
            max = first;
            min = first;
        }
        // Run loop to process all the numbers in file and do the required calculation
        while (inputFile.hasNext())
        {
           // Read a integer from the file.          
            int number = inputFile.nextInt();
            // Count how many numbers are processed
            count++;
            
           // Add number to the value already in total.
           total += number;  
           
           // Compare each line number and get greatest number value and smallest number value
           if (number > max){
                max = number;
            }  
            if(number < min)
            {
               min = number;
            }                   
        }
        inputFile.close();// Close the input file.
        
        // Open output file
        File ofile = new File(outputFileName);
        // Write processed result into output file
        PrintWriter outputFile = new PrintWriter(ofile);
        // Print results in each line
        outputFile.println("Numeric data file name; "+outputFileName );
        outputFile.println("Number of integers: "+ count );
        outputFile.println("The total of all integers in file; "+ total );
        outputFile.println("The largest integer in the set: "+ max );
        outputFile.println("The smallest integer in the set: "+ min );
        outputFile.close();// Close the output file.
        
        // Print process message
        System.out.println("Data written to the file");   
        // Close the output file
        outputFile.close();
        // Return the count value
        return count;
    }
    

}

        // ********* Program solution algorithm ***********   
    
        // 1. Create Method
        // 2. Open the input file. detect if file exist, if not exist, return 0
        // 3. Initial the first line of number as min and max
        // 4. Read each number and process the required statistics
        // 5. Close the input file
        // 6. Open the output file
        // 7. Print processed results in output file
        // 8. Close Output file and notify print successful message
        // 9. Return count value
        // 10. Call Method from Main class
        // 11. Use try/catch clause to properly deal with exceptions

 
    
        // ********* Program solution algorithm ***********   */                  
       

       
    
        
    
    
    
