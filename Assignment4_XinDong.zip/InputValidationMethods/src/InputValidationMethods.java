/*
   Program: InputValidationMethods.java
   Created by: Xin Dong
   This program is to use method to validate input integer number and floating number.
   January 29, 2019
 */
import java.util.Scanner; // Needed for Scanner class


public class InputValidationMethods {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Call validateInt Method to validate integer input
        // try/catch clause to catch exceptions
        try
        {
            int a = validateInt("Please enter an integer");
            System.out.println("Integer entered: "+ a);
            
        }
        catch (Exception e) // handle the exception below
        {
            System.out.println("INPUT ERROR: Please enter an integer number!!"); 
            System.out.println(e.getMessage());
        }   
        // Call validateDouble Method to validate double input
        // try/catch clause to catch exceptions
        try
        {
            double b = validateDouble("Please enter a real number");
            System.out.println("Integer entered: "+ b);
        }
        catch (Exception e) // handle the exception below
        {
            System.out.println("INPUT ERROR: Please enter a floating point number!!"); 
            System.out.println(e.getMessage());
        }
        
    }


/** The method is used to validate user input is integer number. Exception is properly handled.    
     @param prompt  defines the prompted user input value
     @return the input value       
*/
    public static int validateInt(String prompt)
    {
       // Initial variable
        int n = 0;

        // Get the user's input.
        boolean again = true;
        while(again) // input validation loop
        {
          System.out.print("Enter an integer number please:> ");
          // Create a Scanner object to read input.
          Scanner keyboard = new Scanner(System.in);
          prompt = keyboard.nextLine(); // get a string containing an int number
          prompt = prompt.trim(); // remove any extra whitespace from string sides
          try    // trying to convert string to integer, expecting exceptions
          {
            n  = Integer.parseInt(prompt);  // convertion. 

            again =  false; // stop input validation loop
            // continue with the program
          }
          catch (Exception e) // handle the exception below
          {
            System.out.println("INPUT ERROR: Please enter an integer number!!"); 
            System.out.println(e.getMessage());
          }
        } // end of validation loop
             
        
        return n;
    }
/** This method is used to validate user input is floating number. Exception is properly handled.    
     @param prompt  defines the prompted user input value
     @return the input value       
*/
    public static double validateDouble(String prompt)
    {
       // For you to complete
        double n = 0;
        boolean again = true;
        Scanner keyboard = new Scanner(System.in);
        while(again) // input validation loop
        {
          System.out.print("Enter a floating point number please:> ");
          prompt = keyboard.nextLine(); // get a string containing a double number
          prompt = prompt.trim(); // remove any extra whitespace from sides
          try    // trying to convert string to double, expecting exceptions
          {
            n  = Double.parseDouble(prompt);  // convertion. 

            again =  false; // stop input validation loop
            // continue with the program
          }
          catch (Exception e) // handle the exception below
          {
            System.out.println("INPUT ERROR: Please enter a floating point number!!"); 
            System.out.println(e.getMessage());
          }
        } // end of validation loop

        return n;
    }
}