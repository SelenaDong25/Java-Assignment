/*
   Program: PatternDisplay.java
   Created by Xin Dong
   This program is to print patterns of symbols.
   January 29, 2019
 */
package patterndisplay;

/**
 *
 * @author Selena
 */
public class PatternDisplay {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Call patternDisplay method to print symbols.
        // Use try/catch clause to catch exceptions

        try {
            patternDisplay(7, '+', true);
            patternDisplay(7, '#', false);
            patternDisplay(-7, '#', false);
        } catch (Exception e) // handle the exception below
        {
            System.out.println("INPUT ERROR: Please enter a positive number!!");
            System.out.println(e.getMessage());
        }

    }

 /** The method generate symbol patterns and print on the screen.
     The numbers are stored in file in file in specific format: one number per line.
     @param size  defines the size of pattern, in particular the size of the longest sequence of characters in the pattern.
     @param c defines the choice of character that is used to display the patters
     @param direction defines the direction of the pattern.
     @throws IllegalArgumentException when the value of parameter size is a negative number.  
 */
    public static void patternDisplay(int size, char c, boolean direction) throws IllegalArgumentException {
        // Deal with exceptions when input size is negative
        if(size <= 0)
        {
            throw new IllegalArgumentException("Size can't be negative");
        }
        // if-else statement to give different print result based on direction
        // nested for loop to generate symbol pattern
        // system print out pattern
        if (direction) {
            for (int n = 1; n <= size; n++) {

                for (int i = 1; i <= n; i++) {
                    System.out.print(c);
                }
                System.out.println();
            }

        }
        else
        {
            for (int n = size; n >=1; n--) {

                for (int i = 1; i <= n; i++) {
                    System.out.print(c);
                }
                System.out.println();
            }
        }

    }
}
        // ********* Program solution algorithm ***********   
    
        // 1. Create Method
        // 2. Deal with IllegalArgumentException when size input number is negative
        // 3. if-else statement to evaluate true/false direction for pattern display 
        // 4. Nested loop to generate symbol pattern
        // 5. Print out result.
        // 6. Call Method from Main class
        // 7. Use try/catch clause to properly deal with exceptions

 
    
        // ********* Program solution algorithm ***********   */      
