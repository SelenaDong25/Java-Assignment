/*
   Program: RandomNumberaInFile.java
   Created by: Xin Dong
   This program is to use method generates random integers and saves them in a 
        file, placing each new number on a new line.
   January 29, 2019
 */


/**
 *
 * @author Selena
 */
import java.io.*; // Needed for File I/O classes
import java.util.Random; // Needed for Random number class

public class RandomNumberInFile {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Call randomNumsFile method .
        // Use try/catch clause to catch exceptions        
        try{
            randomNumsFile("testOut.txt", 150, 100, 300);
        }
        
        catch(Exception e)
        {
            System.out.println("Error: "+e.getMessage());
        }
            
    }
/** The method generates random integers and saves them in a file, placing each new number on a new line.    
     @param fileName  defines the file name, random number will store in this file
     @param howMany defines number of random numbers to be generated
     @param rangeFrom defines the range of random numbers to be generated.
     @param rangeTo defines the range of random numbers to be generated.
     @throws IOException when the value of parameter size is a negative number.  
 */    
    public static void randomNumsFile(String fileName, int howMany, int rangeFrom, int rangeTo) throws IOException{
    
        // Open the file
        File file = new File(fileName);      
        // Checking if the file already exists.
        // If file already exist, rewrite it and display message
        // If file is not exist, create a new one
        if (file.exists())
        {
            System.out.println("The file " + fileName + 
                    " already exists. Will re-write its content");
        }
        else
        {
            file.createNewFile();
        }       

        // Write numbers to the file.
        PrintWriter outputFile = new PrintWriter(file);
        // Set rangeFrom and rangeTo  
        rangeFrom = rangeFrom > rangeTo ? rangeTo:rangeFrom;
        rangeTo = rangeFrom < rangeTo ? rangeTo:rangeFrom; 
        // Write numbers to the file
        for (howMany = 0; howMany < rangeTo; howMany++)
        {
           Random randomNumbers = new Random();//Create a Random class object
           int randomNumber = randomNumbers.nextInt((rangeTo-rangeFrom)+1)+rangeFrom;//Generate random number with in the range
           outputFile.println(randomNumber);// Print out random number in separate line

        }
        outputFile.close();// Close the file.
        System.out.println("Data written to the file"); // Display message
        }      
    }
        // ********* Program solution algorithm ***********   
    
        // 1. Create Method
        // 2. Open the file. detect if file exist, if exist, rewrite it, if not exist, create a new one
        // 3. Generate random number with in the range
        // 4. Write random numbers into the file, each number in one line
        // 5. Close the file and print message
        // 6. Call Method from Main class
        // 7. Use try/catch clause to properly deal with exceptions

 
    
        // ********* Program solution algorithm ***********   */          

