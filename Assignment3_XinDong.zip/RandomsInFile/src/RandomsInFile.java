/*
   Program: RandomInFile.java
   Created by Xin Dong
   This program is to write 100 random numbers into a file
   January 23, 2019
 */

import java.util.Random; // Needed for Random number class
import java.util.Scanner; // Needed for Scanner class
import java.io.*; // Needed for File I/O classes


public class RandomsInFile {


    public static void main(String[] args) {
        // Define variables
        int randomNumber,range1, range2, min, max, count;
        String filename;               
        // create scanner object to read input
        Scanner keyboard = new Scanner(System.in);
        // prompt user to input range1 for random numbers
        System.out.print("Enter positive number for range: ");
        range1 = keyboard.nextInt();
        // While loop to validate positive range number
        while (range1 < 0 )
        {
            System.out.println("Negative number is not allowed! ");
            System.out.println("Enter positive number for range: ");
            range1 = keyboard.nextInt();
        }
        // prompt user to input range2 for random numbers
        System.out.print("Enter positive number for range: ");
        range2 = keyboard.nextInt();
        // While loop to validate positive range number
        while ( range2 < 0)
        {
            System.out.println("Negative number is not allowed! ");
            System.out.println("Enter positive number for range: ");
            range2 = keyboard.nextInt();
        } 
        
        // prompt user to input file name        
        System.out.print("Enter the file name:");
        filename = keyboard.next();
        // Checking if the file already exists.
        File file = new File(filename);      
        if (file.exists())
        {
            System.out.println("The file " + filename + 
                    " already exists. Will re-write its content");
        }

        
        try{ // handling exceptions if they arise
            // Open the file.
            PrintWriter outputFile = new PrintWriter(file);
            // Set min and max range value 
            max = range1 > range2 ? range1:range2;
            min = range1 < range2 ? range1:range2; 
            // Write numbers to the file
            for (count = 0; count < 100; count++)
            {
                Random randomNumbers = new Random();//Create a Random class object
                randomNumber = randomNumbers.nextInt((max-min)+1)+min;
                outputFile.println(randomNumber);

            }
            outputFile.close();// Close the file.
            System.out.println("Data written to the file");
        }
        catch (IOException e)
        {
            System.out.printf("ERROR writing to file %s!",filename); 
            System.out.printf("ERROR Message: %s!\n",e.getMessage());
        }

        try  
        {
            if (!file.exists())// If file is not exist, create a new file
            {
                boolean filevar = file.createNewFile();
            }
        }
        catch (IOException e)
        {
            System.out.printf("ERROR writing to file %s!",filename); 
            System.out.printf("ERROR Message: %s!\n",e.getMessage());
            System.exit(0);
        }
    }

}
        // ********* Program solution algorithm ***********   
    
        // 1. Create Scanner object
        // 2. Prompt user to input 2 integers as the random number range
        // 3. While loop to validate input integer is valid 
        // 4. Create file object, prompt user to input file name
        // 5. Test if file is already existing, if exist, rewrite the file
        // 6. Use try/catch to catch exception 
        // 7. If file is not exist, create a new file to store data
        // 8. Make sure the range number is in correct sequence, if not, swap them
        // 9. Generate random numbers from the given range
        // 10. Write the random numbers into file, each number take one row
        // 11. Close file
        // 12. print out message
 
    
        // ********* Program solution algorithm ***********   */      
