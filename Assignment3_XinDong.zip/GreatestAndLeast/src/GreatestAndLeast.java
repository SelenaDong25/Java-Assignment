/*
   Program: GreatestAndLeast.java
   Created by Xin Dong
   This program is to be used to find the greatest and least number from a list of numbers
   January 22, 2019
 */

import java.util.Scanner; // Needed for the Scanner class


public class GreatestAndLeast {

    public static void main(String[] args) {
        
        int  greater, least, input; // Declare variables

        Scanner keyboard = new Scanner(System.in); // Create Scanner object
        System.out.print("Enter positive integer or -99 to end:"); // Prompt user to input integer
        input = keyboard.nextInt(); // Get input integer

        greater = input; // Initial the greater number
        least = input; // Initial the least number
        
        // While loop for validation
        // When -99 entered, user is asked to input the correct number
        while (input == -99)
        {
            System.out.println("No numbers were entered.");
            System.out.print("Enter positive integer or -99 to end:");
            input = keyboard.nextInt();
        }
        
        // Set -99 as the end of input
        // Compare number value and get the greater number and least number
        while (input != -99)
        {                                                             
            if (input >= greater){
                greater = input;
            }
            
            if(input <= least)
            {
                least = input;
            }

            System.out.print("Enter positive integer or -99 to end:");
            input = keyboard.nextInt();        
        }
        // Print result
        System.out.println("The greatest number is " + greater);
        System.out.println("The least number is " + least);
            
    }
    
}
        // ********* Program solution algorithm ***********   
    
        // 1. Create Scanner object
        // 2. Prompt user to input first number
        // 3. Initial the first number as the grreater and least number 
        // 4. Validate input, if -99 entered, user will be told that no 
        //                    number entered, and need input number
        // 5. User while loop to compare number value each time when a 
        //    new number is entered. Set -99 as the end signal for inputting
        // 6. Print out result.

 
    
        // ********* Program solution algorithm ***********   */      
