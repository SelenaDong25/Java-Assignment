/*
   Program: e Approximations.java
   Created by Xin Dong
   This program is to calculate e Approximations
   January 23, 2019
 */

import java.util.Scanner; // Needed for Scanner class


public class Approximations {


    public static void main(String[] args) {
    // Declare variables
    int x = 0;
    String str;
        
    // Create a Scanner object to read input.
    Scanner keyboard = new Scanner(System.in);
    
    boolean again = true;   
    while(again) // input validation loop
    {
      System.out.print("Enter an integer number for x please:> ");

      str = keyboard.nextLine(); // get a user input
      str = str.trim(); // remove any extra whitespace from string sides

      try    // trying to convert string to integer, expecting exceptions
      {
        x  = Integer.parseInt(str);  // convertion. 
        //If convertion went well, execution coninues to the next statement below
        again =  false; // stop input validation loop
        // continue with the program
      }
      // If exception occured, will be captured
      catch (Exception e) // handle the exception below
      {
        System.out.println("INPUT ERROR: Please enter an integer number!!"); 
        System.out.println(e.getMessage());
      }
    } // end of validation loop
    // Call ApproximationsToN function with given n
    double approx5th = ApproximationsToN(x, 5);
    double approx10th = ApproximationsToN(x, 10);
    double approx50th = ApproximationsToN(x, 50);
    double approx100th = ApproximationsToN(x, 100);
    
    // Print out e^x Approximation with given n at 5, 10, 50, 100
    System.out.printf("Input x is %d, n is %d \te Approximations is %.2f\n", x,5, approx5th);
    System.out.printf("Input x is %d, n is %d \te Approximations is %.2f\n", x,10, approx10th);
    System.out.printf("Input x is %d, n is %d \te Approximations is %.2f\n", x,50, approx50th);
    System.out.printf("Input x is %d, n is %d \te Approximations is %.2f\n", x,100, approx100th);


    }
    
    // Create function to run for loop multiple times
    public static double ApproximationsToN(int x, int approx)
    {
        double totalApprox = 1;
        long factorial = 1;
        
        // for loop to generate e^x Approximation
        for(int n = 1; n < approx; n++)
        {
            factorial = n * factorial; // calculate factorial
            
            totalApprox += Math.pow(x, n)/factorial; // calculate e^x Approximation

        }
        // return the value of e^x Approximation
        return totalApprox;
    }
    
}
     
        // ********* Program solution algorithm ***********   
    
        // 1. Create Scanner object
        // 2. Use loop to validate input
        // 3. try / catch exception 
        // 4. Create function to be called multiple times
        // 5. Use for loop to calculate factorial and e^x Approximation
        // 6. From main class, call the function 4 times with the given n
        // 7. Print out result.
 
    
        // ********* Program solution algorithm ***********   */      
