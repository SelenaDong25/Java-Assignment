/**
   Program: RestaurantBill.java
   Created by Xin Dong
   This program is to calculate a restaurant bill with tax and tips
   January 8, 2019
 */

import javax.swing.JOptionPane;  // Needed for dispaying diaglog box
import java.text.DecimalFormat;  // Needed for double number roundup 

public class RestaurantBill 
{   
    public static void main(String[] args) 
    {
        String mealCost;      //hold meal cost
        double totalCost;     //hold total cost
        double taxAmount;     //hold tax amount 
        String tipPercentage; //hold tip percentage
        double tipAmount;     //hold tip amount
        
	// Set costant tax percentage
        final double TAX = 0.1;
        
        // Round up double to 2 decimals
        DecimalFormat df = new DecimalFormat ("###.##");  
        
        // Prompt user to enter the meal cost
        mealCost = JOptionPane.showInputDialog("Enter the meal cost");
        // Prompt user to enter the tip percentage       
        tipPercentage = JOptionPane.showInputDialog("Enter the tip percentage");
        // Calculate tax amount
        taxAmount = Double.parseDouble(mealCost) * TAX;
        // Calculate tip amount
        tipAmount = (Double.parseDouble(mealCost) + taxAmount) * 
                                          Double.parseDouble(tipPercentage)/100;
        // Calculate total cost
        totalCost = Double.parseDouble(mealCost) + taxAmount + tipAmount;
        // Display meal cost, tip amount, tax amount and bill total on screen
        JOptionPane.showMessageDialog(null,"Your meal cost is $"+mealCost+".\n" 
                         + "Your meal tax is $" + df.format (taxAmount) + ".\n" 
                         + "Your tip is $" + df.format (tipAmount)+ ".\n" 
                         + "Your bill total is $" + df.format(totalCost)+".");
        // End the program.      
        System.exit(0);
        
    // ********* Program solution algorithm ***********
    
    // Implement the following step-by-step plan
    
    // 1. Enable Dialog Box method
    // 2. Import DecialFormat class
    // 3. Declare double variable to store calculated numbers  
    // 4. Declare string variable for dialog box input
    // 5. Prompt the user with input dialog box to enter meal cost
    // 6. Prompt the user with input dialog box to enter  tip percentage 
    // 7. Input meal cost and tip percentage are stored in variable
    // 8. Convert string to double, calculate tax amount,tip amount
    // 9. Round up double number with 2 decimals
    // 10. Message output the meal cost, tax amount, tip amount & total bill
    
    // ********* Program solution algorithm ***********     
    }
    
}
