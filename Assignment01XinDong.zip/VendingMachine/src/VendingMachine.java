/*
   Program: VendingMachine.java
   Created by Xin Dong
   This program is to calculate changes need machine to dispanse
   January 8, 2019
 */

import javax.swing.JOptionPane;  // Needed for dispaying diaglog box

public class VendingMachine {


    public static void main(String[] args) {

        // Declare dialog box input variable 
        String itemPrice;
        // Declare 1 dollar bill payment        
        final int ITEM_PAY = 100;
        // Prompt costmer to enter the purchased item price
        itemPrice = JOptionPane.showInputDialog("Enter price of item:\n"
                + "(from 25 cents to one dollar, in 5-cent increment)");
        // Calculate changes amount
        int change = ITEM_PAY - Integer.parseInt(itemPrice);
        // Calculate how many quarters in the change
        int quarter = change/25;
        // Calculate change remaining after deducting quarters 
        int subQuarter = change - quarter*25;
        // Calculate how many dimes in the change remaining       
        int dime = subQuarter/10;
        // Calculate change remaining after deducting dimes         
        int subDime = subQuarter - dime*10;
        // Calculate how many nickels in the change remaining
        int nickel = subDime/5;
        // Display calculated results in message window
        JOptionPane.showMessageDialog(null,"You bought an item for " + itemPrice
                         + " cents and gave me a dollar.\nSo your change is:\n"
                         + quarter+" quarters,\n" + dime + " dimes, and\n" 
                         +  nickel + " nickels.\n" );
        // End the program.      
        System.exit(0);
        
    // ********* Program solution algorithm ***********
    
    // Implement the following step-by-step plan
    
    // 1. Enable dialog box input method
    // 2. Declare String input variable
    // 3. Declare 1 dollar payment as integer  
    // 4. Prompt the user to input item price with in defined range
    // 5. Calculate change amount 
    // 6. Calculate quantities of quarters, dimes and nickels within the change 
    // 7. Display the calculation results in message window
    
    // ********* Program solution algorithm ***********   
    }
    
}
