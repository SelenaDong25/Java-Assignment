/*
   Program: ArrayDemo.java
   Created by: Xin Dong
   This program is to test DynamicArray class.
   March 12, 2019
 */
package dynamicarray;


public class ArrayDemo {
    public static void main(String[] args) {
        try
        {
            int[] iarray = {1,2,56,4,7,12,23,27,34,37,39,40,55,78,98};
            
            DynamicArray myArray1 = new DynamicArray();
            DynamicArray myArray2 = new DynamicArray(20);
            DynamicArray myArray3 = new DynamicArray(iarray);

            
            System.out.println(myArray3.findMin() );
            System.out.println(myArray2.getSize() );
            System.out.println(myArray3.get(10) );
            System.out.println(myArray3.indexOf(36) );


        
        }
        catch (IllegalArgumentException e)
        {
            System.out.println("FATAL ERROR: !!"); 
            System.out.println(e.getMessage());
        }
    }
}
