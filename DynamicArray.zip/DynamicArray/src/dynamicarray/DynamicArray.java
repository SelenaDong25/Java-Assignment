/*
   Program: DynamicArray.java
   Created by: Xin Dong
   This program is to create class allows to store array of integers that can 
    grow and shrink as needed, search and sort itself, add and remove elements.
   March 12, 2019
 */
package dynamicarray;


import java.util.Random; // import for random number


public class DynamicArray {

    // Set private variables
    private int array[];
    private int size;
    // Create no argument Constructor and set field to 0
    public DynamicArray(){
        size = 0;

        array = new int[10];
    }
    /**
     The method is to create Constructor with parameter.
     @param size  defines the capacity of initial array.
     @throws IllegalArgumentException when the value of parameter is 0 or a negative number.  
    */
    public DynamicArray(int size){

        if (size <= 0){
            throw new IllegalArgumentException ("ERROR: size cannot be negative.");
        } 
        array = new int[size];
    
    }
    /**
     The method is to create copy Constructor with parameter. It takes an object of 
     type DynamibcArray as a parameter and copies it into the object it creates.
     @param obj  defines an object of type DynamibcArray.
     @throws IllegalArgumentException when the value of parameter is null.  
    */    
    public DynamicArray(int[] obj)throws IllegalArgumentException{
        size = 0;
        array = new int[obj.length];
        for (int index = 0; index < obj.length; index++)
            array[index] = obj[index];
        
        if (obj == null) {
            throw new IllegalArgumentException ("ERROR: passing object cannot be null.");
    }
    
    }
    
    /**
     The method is to get the array size.
     @return array size
    */
    
    public int getSize(){
        size = array.length;
        return size;
    }
    /**
     The method is to copy array field into that new object,.
     @return new array.
    */    
    public int [] toArray(){
        int[] newArray = new int[size];
        for (int index = 0; index < size; index++)
            newArray[index] = array[index];
        return newArray;
    }

    /**
     The method is to adds a new element to the end of the array and increments 
     the size field. If the array is full, increase the capacity of the array
     @param num  defines new element which is to add into array.
    */        
    public void push(int num) {
        int[] newArray = new int[size * 2];
        for (int index = 0; index <= size; index++)
            newArray[index] = array[index];
        newArray[size+1] = num;
        size += size;
        array = newArray;
    }
    /**
     The method is to removes the last element of the array and returns it.
     @return removed array element
     @throws RuntimeException if the array is empty.
    */    
    public int pop() throws RuntimeException{
        int[] shrinkArray = new int[size/2];
        for (int index = 0; index <= size; index++)
            shrinkArray[index] = array[index];
        int removed = shrinkArray[size];
        size -= size;
        return removed;
    }
    /**
     The method is to get element of the array with the requested index.
     @return array element
     @param index pass element index
     @throws IndexOutOfBoundsException if the index number is out of range.
    */    
    public int get(int index) throws IndexOutOfBoundsException {
        int element = array[index]; 
        
        if (index > array.length || index < 0){
            throw new IndexOutOfBoundsException("ERROR: Illegal Index!");
        }
        return element;
    }
    /**
     The method is to get the index of the first occurrence of the
     given number. Returns -1 when the number is not found.
     @return array index
     @param key pass given element
    */    
    public int indexOf(int key){
        int index = 0;
        
        if (key == array[index]){
            return index;
        }
        else            
            return (-1);
    }
    /**
     The method is to adds a new element to the location of the array specified by index parameter.
     @param index pass given index number
     @param num pass given element
     @throws IndexOutOfBoundsException if the index number is out of range.
    */    
    public void add(int index, int num) throws IndexOutOfBoundsException{
        
        array[index] = num;
        if (index > size || index < 0){
            throw new IndexOutOfBoundsException("ERROR: Illegal Index!");
        }
        for (int i = index; i < size; i++){
            array[i+1] = array[i];
        }

        if (array.length > size){
            int[] newArray = new int[size * 2];
            for (index = 0; index <= size; index++)
                newArray[index] = array[index];
            newArray[size+1] = num;
            size += size;
            array = newArray;
        }
    }
    /**
     The method is to remove an element at the specified position in this array.
     @param index pass given index position
     @throws IndexOutOfBoundsException if the index number is out of range.
     @return removed array location index
    */     
    public int remove ( int index) throws IndexOutOfBoundsException{
        int removeIndex;
        int[] removeArray = new int[size];
        
        if (index >= size || index < 0){
            throw new IndexOutOfBoundsException("ERROR: Illegal Index!");
        }        
        for (removeIndex = 0; removeIndex < index; removeIndex++)
            removeArray[removeIndex] = array[index];
        for (removeIndex = index; removeIndex < size; removeIndex++)
            removeArray[removeIndex] = array[index-1];  
        if (removeArray.length <= (size/4))
            System.out.print("FLAG: It is time to shrink the array.");
        
        return removeArray[index];
    }
    /**
     The method is to check if the array size is 0.
     @return true if the size of the array is 0
    */
    public boolean isEmpty(){
        if (size != 0)
            return false;
        return true;
    }
    
    /**
     The method is to sorts the elements of the array.
    */    
    public void sort(){
        for (int i : array){
            for (int j : array){
                if (array[i] < array[j]){
                    int temp = array[i];
                    array[i] = array[j];
                    array[j] = temp;
                }
            }
        }
    }
    
    /**
     The method is to shuffle the elements of the array.
    */      
    public void shuffle(){
        Random random = new Random();
        for (int i = array.length - 1; i > 0; i--){
            int index = random.nextInt(i+1);
            int temp = array[index];
            array[index] = array[i];
            array[i] = temp;
        }
    }
    /**
     The method is to find smallest element in this array.
     @throws RuntimeException if the array is empty.
     @return smallest element
    */         
    public int findMin()throws RuntimeException{
        int lowest = array[0];
        for (int index = 1; index < size; index++){
            if (array[index] < lowest)
                lowest = array[index];          
        }
        return lowest;
    }
    /**
     The method is to find largest element in this array.
     @throws RuntimeException if the array is empty.
     @return largest element
    */     
    public int findMax()throws RuntimeException{
        int highest = array[0];
        for (int index = 1; index < size; index++){
            if (array[index] > highest)
                highest = array[index];          
        }
        return highest;
    }
    /**
     The method is to get an array as a string of comma-separated values.
     @return an array as a string of comma-separated values.
    */        
    public String toString(){
        int index;
        String[] stringArray = new String[size];
        for (index = 0; index < size; index++)
            stringArray[index] = String.valueOf(array[index]);  
        System.out.println(stringArray);
        return stringArray[index];
    }
    /**
     The method is to compares two objects element-by-element and determines 
     if they are exactly the same.
     @return compared result
    */ 
    public boolean equals(DynamicArray obj){
        boolean arrayEqual = true;
        if (this.size == obj.size){
            for (int index = 0; index < size; index++){
                if (this.array[index] != obj.array[index])
                arrayEqual = false;
            }
        }
        else
            arrayEqual = false;                                           
                 
        return arrayEqual;    
        }
    }
    

